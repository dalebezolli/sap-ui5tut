sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("sap.btp.sapui5.controller.View1",{onInit:function(){}})});
//# sourceMappingURL=View1.controller.js.map