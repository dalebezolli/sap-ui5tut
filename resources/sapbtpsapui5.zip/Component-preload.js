//@ui5-bundle sap/btp/sapui5/Component-preload.js
sap.ui.require.preload({
	"sap/btp/sapui5/Component.js":function(){
sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","sap/btp/sapui5/model/models"],function(e,t,i){"use strict";return e.extend("sap.btp.sapui5.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(i.createDeviceModel(),"device")}})});
},
	"sap/btp/sapui5/controller/App.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("sap.btp.sapui5.controller.App",{onInit(){}})});
},
	"sap/btp/sapui5/controller/View1.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("sap.btp.sapui5.controller.View1",{onInit:function(){}})});
},
	"sap/btp/sapui5/i18n/i18n.properties":'# This is the resource bundle for sap.btp.sapui5\n\n#Texts for manifest.json\n\n#XTIT: Application name\nappTitle=Tutorail\n\n#YDES: Application description\nappDescription=A Fiori application.\n#XTIT: Main view title\ntitle=Tutorail',
	"sap/btp/sapui5/manifest.json":'{"_version":"1.49.0","sap.app":{"id":"sap.btp.sapui5","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.10.2","toolsId":"fb6a596d-962b-4f5d-aae5-5513abf6e4bf"},"dataSources":{"mainService":{"uri":"V2/Northwind/Northwind.svc/","type":"OData","settings":{"annotations":[],"localUri":"localService/metadata.xml","odataVersion":"2.0"}}}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.115.1","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"sap.btp.sapui5.i18n.i18n"}},"":{"dataSource":"mainService","preload":true,"settings":{}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"sap.btp.sapui5.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"RouteView1","pattern":":?query:","target":["TargetView1"]}],"targets":{"TargetView1":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"View1","viewName":"View1"}}},"rootView":{"viewName":"sap.btp.sapui5.view.App","type":"XML","async":true,"id":"App"}}}',
	"sap/btp/sapui5/model/models.js":function(){
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"sap/btp/sapui5/view/App.view.xml":'<mvc:View controllerName="sap.btp.sapui5.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="app"></App></mvc:View>\n',
	"sap/btp/sapui5/view/View1.view.xml":'<mvc:View controllerName="sap.btp.sapui5.controller.View1"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><Page id="page" title="{i18n>title}"><content /></Page></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
